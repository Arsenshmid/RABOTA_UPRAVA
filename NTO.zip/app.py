# -*- coding: utf-8 -*-
import os, json, re, uuid, shutil, secrets, datetime, io
from flask import Flask, request, jsonify, session, send_from_directory, send_file, abort
BASE = os.path.dirname(os.path.abspath(__file__))
CFG_PATH = os.path.join(BASE, 'config.json')
if not os.path.exists(CFG_PATH):   # первый запуск: пароли создаются сами
    json.dump({'server': r'localhost\SQLEXPRESS', 'database': 'NtoDB', 'port': 8080,
               'secret': secrets.token_hex(16),
               'users': {'admin': secrets.token_urlsafe(8), 'editor': secrets.token_urlsafe(8)}},
              open(CFG_PATH, 'w', encoding='utf-8'), indent=2)
    print('Создан config.json — в нём пароли admin и editor.')
CFG = json.load(open(CFG_PATH, encoding='utf-8'))
UPLOAD = os.path.join(BASE, 'uploads'); TRASH = os.path.join(UPLOAD, '_удалённые')
for p in (UPLOAD, TRASH):
    if not os.path.isdir(p): os.makedirs(p)
BAD_EXT = set('exe bat cmd com msi scr js vbs ps1 dll jar sh lnk'.split())
app = Flask(__name__, static_folder='static', static_url_path='/static')
app.secret_key = CFG['secret']
app.config['MAX_CONTENT_LENGTH'] = 30 * 1024 * 1024

# ---------- база ----------
def conn():
    import pyodbc
    return pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=%s;DATABASE=%s;Trusted_Connection=yes;TrustServerCertificate=yes'
                          % (CFG['server'], CFG['database']))
def rows(sql, p=()):
    c = conn(); cur = c.cursor(); cur.execute(sql, p)
    cols = [d[0] for d in cur.description]; out = [dict(zip(cols, r)) for r in cur.fetchall()]; c.close(); return out
def run(sql, p=()):
    c = conn(); c.cursor().execute(sql, p); c.commit(); c.close()
def insert(table, d):
    c = conn(); cur = c.cursor(); k = list(d)
    cur.execute('INSERT INTO %s (%s) OUTPUT INSERTED.id VALUES (%s)' % (table, ','.join(k), ','.join('?' * len(k))), [d[x] for x in k])
    i = cur.fetchone()[0]; c.commit(); c.close(); return i

FIELDS = ['in_scheme','scheme_num','address','address_alt','map_url','lat','lon','area','authority','owner_name','inn','ogrn',
          'fns_status','fns_date','obj_kind','trade_type','specialization','trade_area','term_text','term_start','term_end',
          'conditions','notes','contract_state','chk_contract','chk_kkt','chk_match','chk_compare','chk_kupavy','phone','comment','src']
DATES = ('fns_date', 'term_start', 'term_end')

def fmt(v):
    if isinstance(v, datetime.datetime): return v.strftime('%d.%m.%Y %H:%M')
    if isinstance(v, datetime.date): return v.strftime('%d.%m.%Y')
    if v is not None and v.__class__.__name__ == 'Decimal': return float(v)
    return v
def pdate(s):
    s = (s or '').strip()
    if not s: return None
    m = re.match(r'^(\d{2})\.(\d{2})\.(\d{4})$', s)
    if not m: raise ValueError('Дата должна быть в виде ДД.ММ.ГГГГ: ' + s)
    return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))

def state(o):
    """Актуальность договора: считается автоматически."""
    if o.get('contract_state'): return o['contract_state']
    t = ((o.get('conditions') or '') + ' ' + (o.get('notes') or '') + ' ' + (o.get('comment') or '')).lower()
    if 'расторгнут' in t: return 'Расторгнут'
    if 'прекращ' in t: return 'Прекращён'
    if 'на расторжение' in t or 'расторжени' in t: return 'На расторжение'
    e = o.get('term_end')
    if isinstance(e, str):
        try: e = datetime.date(*map(int, e[:10].split('-'))) if e[4:5] == '-' else pdate(e)
        except Exception: e = None
    if isinstance(e, datetime.datetime): e = e.date()
    if e:
        d = (e - datetime.date.today()).days
        return 'Истёк' if d < 0 else ('Истекает' if d < 90 else 'Действует')
    if 'договор' in t or 'дс' in t or (o.get('chk_contract') or '').lower().startswith('есть'): return 'Срок не указан'
    return 'Нет договора'

def prep(o):
    r = {k: fmt(v) for k, v in o.items() if k not in ('created_at', 'updated_at')}
    r['state'] = state(o); r['in_scheme'] = 1 if o.get('in_scheme') else 0
    return r

# ---------- вход ----------
def role(): return session.get('role')
def need(*roles):
    if role() not in roles: abort(401 if not role() else 403)
@app.errorhandler(401)
def _e401(e): return jsonify(error='Нужно войти в систему.'), 401
@app.errorhandler(403)
def _e403(e): return jsonify(error='Недостаточно прав.'), 403
@app.errorhandler(413)
def _e413(e): return jsonify(error='Файл слишком большой (максимум 30 МБ).'), 413

def log(action, oid, before=None, after=None):
    run('INSERT INTO nto_journal (user_name,action,object_id,before_val,after_val) VALUES (?,?,?,?,?)',
        (session.get('user'), action, oid, json.dumps(before, ensure_ascii=False, default=str) if before is not None else None,
         json.dumps(after, ensure_ascii=False, default=str) if after is not None else None))

@app.route('/api/login', methods=['POST'])
def login():
    d = request.get_json() or {}; u = d.get('user'); pw = d.get('password')
    if u in CFG['users'] and CFG['users'][u] == pw:
        session['user'] = u; session['role'] = 'admin' if u == 'admin' else 'editor'
        return jsonify(user=u, role=session['role'])
    return jsonify(error='Неверное имя или пароль.'), 400
@app.route('/api/logout', methods=['POST'])
def logout(): session.clear(); return jsonify(ok=1)
@app.route('/api/me')
def me(): return jsonify(user=session.get('user'), role=role())

# ---------- данные ----------
def clean(d):
    out = {}
    for k in FIELDS:
        if k not in d: continue
        v = d[k]
        if isinstance(v, str): v = v.strip()
        if v == '': v = None
        if k in DATES: v = pdate(v) if v else None
        if k == 'in_scheme': v = 1 if str(v) in ('1', 'True', 'true') else 0
        if k in ('lat', 'lon') and v is not None: v = float(str(v).replace(',', '.'))
        out[k] = v
    if out.get('inn') and not re.fullmatch(r'\d{10}|\d{12}', out['inn']): raise ValueError('ИНН: должно быть 10 цифр (организация) или 12 цифр (ИП).')
    if out.get('ogrn') and not re.fullmatch(r'\d{13}|\d{15}', out['ogrn']): raise ValueError('ОГРН: 13 цифр, ОГРНИП: 15 цифр.')
    return out

@app.route('/api/nto')
def nto_list():
    q = (request.args.get('q') or '').lower().strip(); sc = request.args.get('scheme'); st = request.args.get('state')
    data = [prep(o) for o in rows('SELECT * FROM nto_object WHERE is_deleted=0')]
    cnt = {r['object_id']: r['n'] for r in rows('SELECT object_id, COUNT(*) AS n FROM nto_file WHERE is_deleted=0 GROUP BY object_id')}
    out = []
    for o in data:
        o['files'] = cnt.get(o['id'], 0)
        if sc in ('0', '1') and str(o['in_scheme']) != sc: continue
        if st and o['state'] != st: continue
        if q and q not in ' '.join(str(o.get(k) or '') for k in ('scheme_num','address','address_alt','owner_name','inn','ogrn','specialization','phone','conditions','notes','comment','obj_kind')).lower(): continue
        out.append(o)
    return jsonify(out)

@app.route('/api/nto/<int:i>')
def nto_get(i):
    r = rows('SELECT * FROM nto_object WHERE id=? AND is_deleted=0', (i,))
    if not r: abort(404)
    o = prep(r[0]); o['file_list'] = []
    if role():   # файлы (там могут быть персональные данные) — только после входа
        o['file_list'] = [{k: fmt(v) for k, v in f.items()} for f in
            rows('SELECT id,file_name,caption,is_photo,size_bytes,uploaded_by,uploaded_at FROM nto_file WHERE object_id=? AND is_deleted=0 ORDER BY id', (i,))]
    return jsonify(o)

@app.route('/api/nto', methods=['POST'])
def nto_add():
    need('admin', 'editor')
    try: d = clean(request.get_json() or {})
    except ValueError as e: return jsonify(error=str(e)), 400
    d.setdefault('in_scheme', 1); i = insert('nto_object', d); log('добавление', i, None, d); return jsonify(id=i)

@app.route('/api/nto/<int:i>', methods=['PUT'])
def nto_edit(i):
    need('admin', 'editor')
    old = rows('SELECT * FROM nto_object WHERE id=? AND is_deleted=0', (i,))
    if not old: abort(404)
    try: d = clean(request.get_json() or {})
    except ValueError as e: return jsonify(error=str(e)), 400
    ch = {k: v for k, v in d.items() if (old[0][k] if not isinstance(old[0][k], bool) else int(old[0][k])) != v and not (old[0][k] is None and v is None)}
    if ch:
        run('UPDATE nto_object SET %s, updated_at=SYSDATETIME() WHERE id=?' % ','.join(k + '=?' for k in ch), list(ch.values()) + [i])
        log('изменение', i, {k: old[0][k] for k in ch}, ch)
    return jsonify(ok=1, changed=len(ch))

@app.route('/api/nto/<int:i>', methods=['DELETE'])
def nto_del(i):
    need('admin')
    old = rows('SELECT * FROM nto_object WHERE id=? AND is_deleted=0', (i,))
    if not old: abort(404)
    log('удаление', i, old[0], None)   # снимок записи остаётся в журнале
    run('UPDATE nto_object SET is_deleted=1, updated_at=SYSDATETIME() WHERE id=?', (i,))
    return jsonify(ok=1)

# ---------- файлы ----------
@app.route('/api/nto/<int:i>/files', methods=['POST'])
def file_add(i):
    need('admin', 'editor')
    if not rows('SELECT id FROM nto_object WHERE id=? AND is_deleted=0', (i,)): abort(404)
    f = request.files.get('file')
    if not f or not f.filename: return jsonify(error='Файл не выбран.'), 400
    ext = f.filename.rsplit('.', 1)[-1].lower() if '.' in f.filename else ''
    if ext in BAD_EXT or not ext: return jsonify(error='Этот тип файла загружать нельзя.'), 400
    stored = uuid.uuid4().hex + '.' + ext
    folder = os.path.join(UPLOAD, 'nto_%d' % i)
    if not os.path.isdir(folder): os.makedirs(folder)
    f.save(os.path.join(folder, stored))
    photo = 1 if ext in ('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic') else 0
    fid = insert('nto_file', dict(object_id=i, file_name=f.filename[:300], stored_name=stored, caption=(request.form.get('caption') or '')[:300],
                 is_photo=photo, size_bytes=os.path.getsize(os.path.join(folder, stored)), uploaded_by=session.get('user')))
    log('файл добавлен', i, None, {'file': f.filename})
    return jsonify(id=fid)

def frow(fid):
    r = rows('SELECT * FROM nto_file WHERE id=? AND is_deleted=0', (fid,))
    if not r: abort(404)
    return r[0]
@app.route('/api/files/<int:fid>')
def file_get(fid):
    need('admin', 'editor'); r = frow(fid)
    return send_from_directory(os.path.join(UPLOAD, 'nto_%d' % r['object_id']), r['stored_name'],
                               as_attachment=not r['is_photo'], download_name=r['file_name'])
@app.route('/api/files/<int:fid>', methods=['DELETE'])
def file_del(fid):
    need('admin', 'editor'); r = frow(fid)
    src = os.path.join(UPLOAD, 'nto_%d' % r['object_id'], r['stored_name'])
    if os.path.exists(src): shutil.move(src, os.path.join(TRASH, '%d_%s' % (fid, r['stored_name'])))
    run('UPDATE nto_file SET is_deleted=1 WHERE id=?', (fid,)); log('файл удалён', r['object_id'], {'file': r['file_name']}, None)
    return jsonify(ok=1)

@app.route('/api/journal')
def journal():
    need('admin')
    return jsonify([{k: fmt(v) for k, v in r.items()} for r in rows('SELECT TOP 300 * FROM nto_journal ORDER BY id DESC')])

@app.route('/api/export.xlsx')
def export():
    import openpyxl
    from openpyxl.styles import Font
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = 'НТО'
    head = ['ID', 'В схеме', '№'] + FIELDS[2:] + ['Договор (расчёт)']
    ws.append(head)
    for c in ws[1]: c.font = Font(bold=True)
    for r in rows('SELECT * FROM nto_object WHERE is_deleted=0 ORDER BY in_scheme DESC, id'):
        p = prep(r); ws.append([p['id'], 'да' if p['in_scheme'] else 'нет', p['scheme_num']] + [p.get(k) for k in FIELDS[2:]] + [p['state']])
    b = io.BytesIO(); wb.save(b); b.seek(0)
    return send_file(b, as_attachment=True, download_name='НТО_%s.xlsx' % datetime.date.today().strftime('%d.%m.%Y'))

@app.route('/')
def index(): return send_from_directory(os.path.join(BASE, 'static'), 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=CFG.get('port', 8080), threaded=True)
